package com.otakuexchange.application.controllers

import com.otakuexchange.domain.event.Event
import com.otakuexchange.domain.market.Market
import com.otakuexchange.domain.market.Order
import com.otakuexchange.domain.market.Topic
import com.otakuexchange.domain.repositories.IEventRepository
import com.otakuexchange.domain.repositories.IMarketRepository
import com.otakuexchange.domain.repositories.IOrderRecordRepository
import com.otakuexchange.domain.repositories.ITopicRepository
import com.otakuexchange.domain.repositories.ITradeHistoryRepository
import com.otakuexchange.domain.services.OrderMatchingService
import com.otakuexchange.plugins.userId
import io.ktor.http.HttpStatusCode
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import kotlin.uuid.Uuid

class OrderController(
    private val orderRecordRepository: IOrderRecordRepository,
    private val tradeHistoryRepository: ITradeHistoryRepository,
    private val marketRepository: IMarketRepository,
    private val eventRepository: IEventRepository,
    private val topicRepository: ITopicRepository,
    private val orderMatchingService: OrderMatchingService
) : IRouteController {

    override fun registerRoutes(route: Route) {

        route.post("/orders") {
            val order = call.receive<Order>()
            val userId = Uuid.parse(call.userId)

            val marketWithEntity = marketRepository.getById(order.marketId)
                ?: return@post call.respond(HttpStatusCode.NotFound, "Market not found")
            val eventWithBookmark = eventRepository.getById(marketWithEntity.eventId, userId)
                ?: return@post call.respond(HttpStatusCode.NotFound, "Event not found")
            val topic = topicRepository.getById(eventWithBookmark.topicId)
                ?: return@post call.respond(HttpStatusCode.NotFound, "Topic not found")

            // Extract base Market and Event for the matching service
            val market = Market(
                id = marketWithEntity.id,
                eventId = marketWithEntity.eventId,
                label = marketWithEntity.label,
                status = marketWithEntity.status
            )
            val event = Event(
                id = eventWithBookmark.id,
                topicId = eventWithBookmark.topicId,
                format = eventWithBookmark.format,
                name = eventWithBookmark.name,
                description = eventWithBookmark.description,
                closeTime = eventWithBookmark.closeTime,
                status = eventWithBookmark.status,
                resolutionRule = eventWithBookmark.resolutionRule
            )

            val userOrder = order.copy(userId = userId)
            orderMatchingService.submitOrder(userOrder, market, event, topic)
            call.respond(HttpStatusCode.Accepted, userOrder)
        }

        route.get("/orders/me") {
            val userId = Uuid.parse(call.userId)
            val orders = orderRecordRepository.findByUserId(userId)
            call.respond(orders)
        }

        route.get("/orders/{id}") {
            val id = try { Uuid.parse(call.parameters["id"] ?: "") }
            catch (e: Exception) { call.respond(HttpStatusCode.BadRequest, "Invalid id"); return@get }
            val order = orderRecordRepository.findById(id)
            if (order == null) call.respond(HttpStatusCode.NotFound, "Order not found")
            else call.respond(order)
        }

        route.get("/markets/{marketId}/orders") {
            val marketId = try { Uuid.parse(call.parameters["marketId"] ?: "") }
            catch (e: Exception) { call.respond(HttpStatusCode.BadRequest, "Invalid marketId"); return@get }
            val orders = orderRecordRepository.findByMarketId(marketId)
            call.respond(orders)
        }

        route.delete("/orders/{id}") {
            val id = try { Uuid.parse(call.parameters["id"] ?: "") }
            catch (e: Exception) { call.respond(HttpStatusCode.BadRequest, "Invalid id"); return@delete }
            val userId = Uuid.parse(call.userId)
            val order = orderRecordRepository.findById(id)
            when {
                order == null -> call.respond(HttpStatusCode.NotFound, "Order not found")
                order.userId != userId -> call.respond(HttpStatusCode.Forbidden, "Not your order")
                else -> {
                    orderMatchingService.cancelOrder(id)
                    call.respond(HttpStatusCode.NoContent)
                }
            }
        }

        route.get("/markets/{marketId}/trades") {
            val marketId = try { Uuid.parse(call.parameters["marketId"] ?: "") }
            catch (e: Exception) { call.respond(HttpStatusCode.BadRequest, "Invalid marketId"); return@get }
            val since = call.request.queryParameters["since"]?.toLongOrNull()
            val trades = if (since != null)
                tradeHistoryRepository.findByMarketIdSince(marketId, since)
            else
                tradeHistoryRepository.findByMarketId(marketId)
            call.respond(trades)
        }
    }
}